import {Link} from "react-router";

export function Navigation() {
    return (
        <>
            <header>
                <ul>
                    <Link to="/">Dashboard</Link>
                    <Link to="/add">Add Customer</Link>
                    <Link to="/update">Update Customer</Link>
                    <Link to="/delete">Delete Customer</Link>
                </ul>
            </header>
        </>
    );
}