import {useContext, useState} from "react";
import {CustomerContext} from "../component/CustomerProvider.tsx";

export function DeleteCustomer() {

    // const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    // const [phone, setPhone] = useState('');

    const [customers, setCustomers] = useContext(CustomerContext);

    function handleDelete() {
        setCustomers((customers) => customers.filter((customer) => customer.email !== email));
    }
    return (
        <>
            Delete Customer

            <br/>

            {/*<input type={"text"} placeholder={"Name"} onChange={(e) => setName(e.target.value)}/>*/}
            <input type={"text"} placeholder={"Email"} onChange={(e) => setEmail(e.target.value)}/>
            {/*<input type={"text"} placeholder={"Contact"} onChange={(e) => setPhone(e.target.value)}/>*/}

            <br/>

            <button onClick={handleDelete}>Delete</button>
        </>
    );
}