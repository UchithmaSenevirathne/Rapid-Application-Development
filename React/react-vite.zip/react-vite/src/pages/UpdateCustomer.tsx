import {useContext, useState} from "react";
import {CustomerContext} from "../component/CustomerProvider.tsx";

export function UpdateCustomer() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');

    const [customers, setCustomers] = useContext(CustomerContext);

    function handleUpdate() {
        setCustomers(
            customers.map((customer) =>
                customer.email === email
                    ? {
                        ...customer,
                        name: name,
                        email: email,
                        phone: phone,
                    }
                    : customer
            )
        );
    }

    return (
        <>
            Update Customer

            <br/>

            <input type={"text"} placeholder={"Name"} onChange={(e) => setName(e.target.value)}/>
            <input type={"text"} placeholder={"Email"} onChange={(e) => setEmail(e.target.value)}/>
            <input type={"text"} placeholder={"Contact"} onChange={(e) => setPhone(e.target.value)}/>

            <br/>

            <button onClick={handleUpdate}>Update</button>
        </>
    );
}