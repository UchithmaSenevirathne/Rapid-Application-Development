import {useContext, useState} from "react";
import {CustomerContext} from "../component/CustomerProvider.tsx";

export function Dashboard() {
    const [customers, setCustomers] = useContext(CustomerContext);
    return (
        <>
            Dashboard

            <br/>

            {customers.map((customer) => (
                <div>{customer.name + ' ' + ' ' + customer.email + ' ' + customer.phone}</div>
            ))}
        </>
    );
}