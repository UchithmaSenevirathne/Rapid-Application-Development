import {useContext, useState} from "react";
import {CustomerContext} from "../component/CustomerProvider.tsx";
import {Customer} from "../models/Customer.ts";

export function AddCustomer() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');

    const [customers, setCustomers] = useContext(CustomerContext);

    function handleSubmit() {
        const newCustomer = new Customer(name,email,phone);
        setCustomers((customers) => [...customers, newCustomer]);
    }

    return (
        <>
            Add Customer

            <br/>

            <input type={"text"} placeholder={"Name"} onChange={(e) => setName(e.target.value)}/>
            <input type={"text"} placeholder={"Email"} onChange={(e) => setEmail(e.target.value)}/>
            <input type={"text"} placeholder={"Phone"} onChange={(e) => setPhone(e.target.value)}/>

            <br/>

            <button onClick={handleSubmit}>Add</button>
        </>
    );
}