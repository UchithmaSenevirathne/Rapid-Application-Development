export const ItemList = [
    {
        title:"A",
        description:"this is a description",
    },
    {
        title:"B",
        description:"this is a description",
    },
    {
        title:"C",
        description:"this is a description",
    }
]